# OnlineVotingSystem

Online Voting System with RSA and SHA-256 encryption algorithms using Servlet-JSP framework in Java !!
